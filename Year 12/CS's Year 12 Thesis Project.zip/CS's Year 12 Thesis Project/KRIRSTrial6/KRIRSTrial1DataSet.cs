﻿namespace KRIRSTrial6
{


    partial class KRIRSTrial1DataSet
    {
    }
}
