﻿/**
 * Sarmiento, Chyna Ezra S.
 * March 2019
 * Key Result Indicators Report Software
 * High School Thesis
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KRIRSTrial6
{
    /// <summary>
    /// Interaction logic for g12grit.xaml
    /// </summary>
    
    public partial class g12grit : Window
    {
        public g12grit()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            new Grade12().Show();
        }

        private void btnKRI(object sender, RoutedEventArgs e)
        {
            new KeyResultIndicators().Show();
        }
    }
}
