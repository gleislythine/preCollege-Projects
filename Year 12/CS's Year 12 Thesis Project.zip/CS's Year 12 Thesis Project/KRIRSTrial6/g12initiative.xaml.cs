﻿/**
 * Sarmiento, Chyna Ezra S.
 * March 2019
 * Key Result Indicators Report Software
 * High School Thesis
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KRIRSTrial6
{
    /// <summary>
    /// Interaction logic for g12initiative.xaml
    /// </summary>

    public partial class g12initiative : Window
    {
        ViolationsPageDataContext dc = new ViolationsPageDataContext(Properties.Settings.Default.KRIRSTrial1ConnectionString);

        public g12initiative()
        {
            InitializeComponent();

            if (dc.DatabaseExists())
            {
                dg12STEMa.ItemsSource = dc.vwStudentLists;
            }
        }

        private void btnBackG12(object sender, RoutedEventArgs e)
        {
            new Grade12().Show();
        }

        private void Dg12STEMa_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            new StudentInfo().Show();
        }

        private void btnKRI(object sender, RoutedEventArgs e)
        {
            new KeyResultIndicators().Show();
        }
    }
}